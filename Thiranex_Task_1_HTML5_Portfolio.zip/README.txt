THIRANEX TASK 1
HTML5 Semantic Structure & Accessibility

Project: Personal Portfolio Website
Author: Priyanka Rajput
Year: 2026

Files:
- index.html
- about.html
- projects.html
- contact.html

Implemented:
- Semantic HTML5 elements: header, nav, main, section, article, aside, footer
- Accessible navigation with aria-label and aria-current
- Logical heading hierarchy
- SEO-friendly title and meta description on every page
- Accessible contact form with labels, required fields, fieldset and legend
- Keyboard-friendly native HTML controls
- Language declaration and responsive viewport metadata
- Multi-page internal navigation

To view:
Open index.html in a browser.

Note:
This is the HTML5/accessibility stage of the portfolio. Styling and advanced CSS can be added in the next task.
